<li class="nav-item">
    <a href="<?php echo e(url('jornadas')); ?>"
        class="<?php echo e(Request::path() === 'usuarios' ? 'nav-link active' : 'nav-link'); ?>">
        <i class="nav-icon fas fa-users"></i>
        <p>
            Jornadas
            
        </p>
    </a>
</li><?php /**PATH C:\laragonx64\www\gestor\resources\views/menu/jornalero.blade.php ENDPATH**/ ?>