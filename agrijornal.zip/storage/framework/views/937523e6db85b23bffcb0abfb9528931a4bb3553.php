<div class="container">
    <h2>Lista de jornales <a href="jornadas/create"><button type="button" class="btn btn-success float-right">Crear Jornal</button></a></h2>


    <table class="table text-center">
        <thead class="thead-dark">
        <tr>
            <th scope="col">Nombre Completo</th>
            <th scope="col">Dia</th>
            <th scope="col">Hora de entrada</th>
            <th scope="col">Hora de salida</th>
            <th scope="col">Pagado</th>
            <th scope="col">Precio por hora</th>
            <th scope="col">Opciones</th>

        </tr>
        </thead>
        <tbody>
           
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $jornadas->where('id_user', $user->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jornada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($user->name); ?> <?php echo e($user->apellido1); ?> <?php echo e($user->apellido2); ?></th>
                        <td><?php echo e($jornada->dia); ?></td>
                        <td><?php echo e($jornada->inicio_jornada); ?></td>
                        <td><?php echo e($jornada->fin_jornada); ?></td>
                        <?php if($jornada->pagado == 1): ?>
                            <td>Si</td>
                        <?php else: ?>
                            <td>No</td>
                        <?php endif; ?>
                        <td><?php echo e($jornada->precio_hora); ?></td>
                        <td>
                            <form action="<?php echo e(route('jornadas.destroy',$jornada->id)); ?> " method="POST">          
                                <a href="<?php echo e(route ('jornadas.edit', $jornada->id)); ?>"><button type="button" class="btn btn-primary btn-sm"><i class="far fa-edit"></i></button></a>
                                  <?php echo csrf_field(); ?> 
                                  <?php echo method_field('DELETE'); ?>
                                  <button type="submit" class="btn btn-danger btn-sm"><i class="far fa-trash-alt"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </tbody>
    </table>

</div><?php /**PATH C:\laragonx64\www\gestor\resources\views/jornadas/agricultor.blade.php ENDPATH**/ ?>