<?php $__env->startSection('content'); ?>
<div class="container">
    <h2>Lista de jornaleros <a href="usuarios/create"><button type="button" class="btn btn-success float-right">agregar usuario</button></a></h2>


    <table class="table">
        <thead class="thead-dark">
        <tr>
            <th scope="col">Nombre completo</th>
            <th scope="col">NIF</th>
            <th scope="col">Dinero a deber</th>
            <th scope="col">Total de jornadas</th>
            <th scope="col">Opciones</th>

        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            
            
            <tr>
                <th scope="row"><?php echo e($users->name); ?> <?php echo e($users->apellido1); ?> <?php echo e($users->apellido2); ?></th>
                <td><?php echo e($users->nif); ?></td>
                <?php 
                $dinero_total=0;
                $jornada_total=0;
                
                foreach ($jornadas as $jornada){
                    if ($jornada->id_user == $users->id) {
                        if ($jornada->pagado == 0) {
                        $dinero_total += ( strtotime($jornada->fin_jornada)-strtotime($jornada->inicio_jornada) )/3600*$jornada->precio_hora;
                    }
                    $jornada_total += 1;
                    }
                    
                }
                ?>
                <td><?php echo e($dinero_total); ?></td>
                <td><?php echo e($jornada_total); ?></td>
                <td>
                    <form action="<?php echo e(route('usuarios.destroy',$users->id)); ?> " method="POST">
                    
          
                  <a href="<?php echo e(route ('usuarios.edit', $users->id)); ?>"><button type="button" class="btn btn-primary btn-sm"><i class="far fa-edit"></i></button></a>
                    <?php echo csrf_field(); ?> 
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger btn-sm"><i class="far fa-trash-alt"></i></button>
                    </form></td>
    
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        </tbody>
    </table>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragonx64\www\gestor\resources\views/usuarios/index.blade.php ENDPATH**/ ?>