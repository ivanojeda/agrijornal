<div class="container">
    <h2>Lista de jornales</h2>


    <table class="table text-center">
        <thead class="thead-dark">
        <tr>
            <th scope="col">Dia</th>
            <th scope="col">Hora de entrada</th>
            <th scope="col">Hora de salida</th>
            <th scope="col">Pagado</th>
            <th scope="col">Precio por hora</th>
        </tr>
        </thead>
        <tbody>  
                <?php $__currentLoopData = $jornadas->where('id_user', $u->id); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jornada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($jornada->dia); ?></td>
                        <td><?php echo e($jornada->inicio_jornada); ?></td>
                        <td><?php echo e($jornada->fin_jornada); ?></td>
                        <?php if($jornada->pagado == 1): ?>
                            <td>Si</td>
                        <?php else: ?>
                            <td>No</td>
                        <?php endif; ?>
                        <td><?php echo e($jornada->precio_hora); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </tbody>
    </table>

</div><?php /**PATH C:\laragonx64\www\gestor\resources\views/jornadas/jornalero.blade.php ENDPATH**/ ?>