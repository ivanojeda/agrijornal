<?php $__env->startSection('content'); ?>
<?php $u = App\User::find( auth()->user()->id );
$us =  $u->roles()->first()->name;?>
<?php if($us == 'agricultor'): ?>
    <?php echo $__env->make('jornadas.agricultor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif($us == 'jornalero'): ?>
    <?php echo $__env->make('jornadas.jornalero', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
<?php header("Location: /");
die(); ?>
<?php endif; ?>   
<?php $__env->stopSection(); ?> 

<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragonx64\www\gestor\resources\views/jornadas/index.blade.php ENDPATH**/ ?>