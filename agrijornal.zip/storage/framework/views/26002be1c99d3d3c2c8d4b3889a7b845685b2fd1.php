<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row">
        <div class="col-sm-6">
        <h2>Editar usuario: <?php echo e($user->name); ?></h2>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

        </div>
    </div>


<form action="<?php echo e(route('usuarios.update', $user->id)); ?>" method="POST" enctype="multipart/form-data">
    <?php echo method_field('PATCH'); ?>
    <?php echo csrf_field(); ?>
    <div class="form-row">
        <div class="form-group col-md-4">
            <label>Nombre</label>
            <input type="text" name="name" value="<?php echo e($user->name); ?>" class="form-control" placeholder="Nombre">
        </div>
        <div class="form-group col-md-4">
            <label>Primer Apellido</label>
            <input type="text" name="apellido1" value="<?php echo e($user->apellido1); ?>" class="form-control" placeholder="Primer Apellido">
        </div>
        <div class="form-group col-md-4">
            <label>Segundo Apellido</label>
            <input type="text" name="apellido2" value="<?php echo e($user->apellido2); ?>" class="form-control" placeholder="Segundo Apellido">
        </div>
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <label>Telefono</label>
            <input type="text" name="telefono" value="<?php echo e($user->telefono); ?>" class="form-control" placeholder="Teledono">
        </div>
        <div class="form-group col-md-4">
            <label>NIF</label>
            <input type="text" name="nif" value="<?php echo e($user->nif); ?>" class="form-control" placeholder="NIF">
        </div>
        <div class="form-group col-md-4">
            <label>Email</label>
            <input type="email" name="email" value="<?php echo e($user->email); ?>" class="form-control" placeholder="Email">
        </div>
    </div>


        <div class="form-row">
            <div class="form-group col-md-6">
                <label>Contraseña</label>
                <input type="password" name="password" class="form-control" placeholder="Contraseña">
            </div>
            <div class="form-group col-md-6">
                <label>confirmar contraseña</label>
                <input type="password" name="password_confirmation" class="form-control" placeholder="Confirme Contraseña">
            </div>

            <div class="form-group col-md-6">
                <button type="submit" class="btn btn-primary">Registrar Jornalero</button>
                <button type="reset" onclick="history.back()" class="btn btn-danger">cancelar</button>
            </div>
        </div>
            </form>
        
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragonx64\www\gestor\resources\views/usuarios/edit.blade.php ENDPATH**/ ?>