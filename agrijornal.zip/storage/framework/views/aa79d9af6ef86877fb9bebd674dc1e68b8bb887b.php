<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="jumbotron jumbotron-fluid">
        <div class="container">
        <h1 class="display-4"><?php echo e($user->name); ?> <?php echo e($user->apellido1); ?> <?php echo e($user->apellido2); ?></h1>
        <p class="lead">Correo: <?php echo e($user->email); ?></p>
        <p class="lead">Nif: <?php echo e($user->nif); ?></p>
        <p class="lead">Telefono: <?php echo e($user->telefono); ?></p>

        </div>
    </div>

    <table class="table">
        <thead class="thead-dark">
        <tr>
            <th scope="col">Dia</th>
            <th scope="col">Hora de entrada</th>
            <th scope="col">Hora de salida</th>
            <th scope="col">Pagado</th>
            <th scope="col">Precio por hora</th>
            <th scope="col">Opciones</th>

        </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $jornadas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jornada): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
            
            
            <tr>
                <th scope="row"><?php echo e($jornada->dia); ?></th>
                <td><?php echo e($jornada->inicio_jornada); ?></td>
                
                <td><?php echo e($jornada->fin_jornada); ?></td>
                <?php if($jornada->pagado == 1): ?>
                <td>Si</td>
                <?php else: ?>
                <td>No</td>
                <?php endif; ?>
                <td><?php echo e($jornada->precio_hora); ?></td>
                <td>
                    
                </td>
                
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        
        </tbody>
    </table>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragonx64\www\gestor\resources\views/usuarios/show.blade.php ENDPATH**/ ?>