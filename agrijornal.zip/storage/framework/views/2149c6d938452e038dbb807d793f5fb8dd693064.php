<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-sm-4">
            <h2>Crear un nuevo jornal</h2>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

        </div>
    </div>


<form action="/jornadas" method="POST" enctype="multipart/form-data">
    <?php echo csrf_field(); ?>
    <div class="form-row">
        <div class="form-group col-md-4">
            <label for="user">Jornalero</label>
            <select name="jornalero" class="form-control">
                <option selected disabled>Elige el jornalero</option>
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($user->id); ?>"><?php echo e($user->nif); ?> - <?php echo e($user->name); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group col-md-4">
            <label>Dia</label>
            <input type="date" name="dia" class="form-control" >
        </div>
        <div class="form-group col-md-4">
            <label>Precio por Hora</label>
            <input type="number" min="0" step="0.01" name="precio_hora" class="form-control">
        </div>
        
    </div>

    <div class="form-row">
        <div class="form-group col-md-4">
            <label>Inicio de la Jornada</label>
            <input type="time" name="inicio_jornada" class="form-control">
        </div>
        <div class="form-group col-md-4">
            <label>Fin de la Jornada</label>
            <input type="time" name="fin_jornada" class="form-control">
        </div>

        <div class="form-row">
            <label for="pagado">Pagado: </label>
            <input type="radio" name="pagado" id="pagado" value="1">Si<br>
            <input type="radio" name="pagado" id="pagado" value="0" checked>No<br>
        </div>

        <div class="form-group col-md-6">
            <button type="submit" class="btn btn-primary">Registrar Jornalero</button>
            <button type="reset" class="btn btn-danger">cancelar</button>
        </div>
        
    </div>
    

</form>
        
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragonx64\www\gestor\resources\views/jornadas/create.blade.php ENDPATH**/ ?>